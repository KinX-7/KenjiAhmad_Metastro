﻿Imports System.Data.SqlClient
Public Class caribuku
    Sub dgv()
        Call koneksi()
        da = New SqlDataAdapter("select BukuID, Judul, Kategori from tbl_buku", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_buku")
        DataGridView1.DataSource = (ds.Tables("tbl_buku"))
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub caribuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call dgv()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        If DataGridView1.SelectedCells.Count > 0 Then
            Dim selectedCell As DataGridViewCell = DataGridView1.SelectedCells(0)

            ' Mendapatkan nilai dari sel-sel dalam satu baris
            Dim dataForTextBox1 As String = DataGridView1(0, selectedCell.RowIndex).Value.ToString()
            Dim dataForTextBox2 As String = DataGridView1(1, selectedCell.RowIndex).Value.ToString()
            Dim dataForTextBox3 As String = DataGridView1(2, selectedCell.RowIndex).Value.ToString()
            Dashboard.txtbkidpnjm.Text = dataForTextBox1
            Dashboard.txtjdlpnjm.Text = dataForTextBox2
            Dashboard.txtktgrpnjm.Text = dataForTextBox3
            Me.Close()

        End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class