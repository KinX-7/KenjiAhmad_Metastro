﻿Imports System.Data.SqlClient
Module Module1
    Public conn As SqlConnection
    Public da As SqlDataAdapter
    Public ds As DataSet
    Public rd As SqlDataReader
    Public cmd As SqlCommand
    Public mydb As String
    Public Sub koneksi()
        mydb = "data source=localhost\SQLEXPRESS; initial catalog=db_ukom; integrated security=true"
        conn = New SqlConnection(mydb)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub
End Module
