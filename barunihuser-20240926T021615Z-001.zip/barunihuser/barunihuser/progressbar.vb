﻿Public Class progressbar
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(10)
        If ProgressBar1.Value = 100 Then
            Timer1.Enabled = False
            Me.Close()
            Dashboard.Show()
        End If
    End Sub

    Private Sub progressbar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class