﻿Imports System.Data.SqlClient
Public Class editdatauser

    Public Sub userdata()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID, Username, Password, Nama, Email, Telp, Alamat FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    txtidedt.Text = reader("UserID").ToString()
                    txtusrnmedt.Text = reader("Username").ToString()
                    txtpwedt.Text = reader("Password").ToString()
                    txtnmedt.Text = reader("Nama").ToString()
                    txtemledt.Text = reader("Email").ToString()
                    txttlpedt.Text = reader("Telp").ToString()
                    txtalmtedt.Text = reader("Alamat").ToString()

                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Public Sub userdataupdate()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID, Username, Password, Nama, Email, Telp, Alamat FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", txtusrnmedt.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    Dashboard.txtuseriddb.Text = reader("UserID").ToString()
                    Dashboard.txtusrnmdb.Text = reader("Username").ToString()
                    Dashboard.txtpwdb.Text = reader("Password").ToString()
                    Dashboard.txtnmdb.Text = reader("Nama").ToString()
                    Dashboard.txtemldb.Text = reader("Email").ToString()
                    Dashboard.txttlpdb.Text = reader("Telp").ToString()
                    Dashboard.txtalmtdb.Text = reader("Alamat").ToString()

                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub editdatauser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtusrnmedt.Focus()
        txtidedt.Visible = False
        Call userdataupdate()
        Call userdata()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If MessageBox.Show("Batalkan Perubahan?", "Pemberitahuan!", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'txtusrnmedt.Text = ""
        'txtpwedt.Text = ""
        'txtnmedt.Text = ""
        'txtemledt.Text = ""
        'txttlpedt.Text = ""
        'txtalmtedt.Text = ""
        txtusrnmedt.Focus()
        Call userdata()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        'Dashboard.txtuseriddb.Text = ""
        'Dashboard.txtusrnmdb.Text = ""
        'Dashboard.txtpwdb.Text = ""
        'Dashboard.txtnmdb.Text = ""
        'Dashboard.txtemldb.Text = ""
        'Dashboard.txttlpdb.Text = ""
        'Dashboard.txtalmtdb.Text = ""
        If txtusrnmedt.Text = "" Or txtpwedt.Text = "" Or txtnmedt.Text = "" Or txtemledt.Text = "" Or txttlpedt.Text = "" Or txtalmtedt.Text = "" Then
            MsgBox("Data Belum Lengkap..!", vbInformation, "GAGAL!")
        Else
            If MessageBox.Show("Simpan Perubahan?", "Pemberitahuan!", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi()
                Dim EDIT As String = "update tbl_user set Username='" & txtusrnmedt.Text & "',Password='" & txtpwedt.Text & "',Nama='" & txtnmedt.Text & "',Email='" & txtemledt.Text & "',Telp='" & txttlpedt.Text & "',Alamat='" & txtalmtedt.Text & "' where UserID='" & txtidedt.Text & "'"
                cmd = New SqlCommand(EDIT, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Berhasil Diedit!", vbInformation, "SUKSES!")
                Call userdataupdate()
                Me.Close()
            End If
        End If
    End Sub
End Class