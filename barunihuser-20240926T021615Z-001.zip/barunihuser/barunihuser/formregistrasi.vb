﻿Imports System.Data.SqlClient

Public Class formregistrasi
    Sub autoiduser()
        txtusrid.Visible = False
        Call koneksi()
        Dim query As New SqlCommand("select * from tbl_user where UserID in(select max(UserID) from tbl_user)", conn)
        Dim er = query.ExecuteReader
        er.Read()

        If Not er.HasRows Then
            txtusrid.Text = "USR" + "001"
            conn.Close()
        Else
            Dim cekid = Microsoft.VisualBasic.Right(er.GetString(0), 3) + 1
            txtusrid.Text = "USR" + Microsoft.VisualBasic.Right("000" & cekid, 3)

        End If
    End Sub
    Sub kondisiawalregis()
        txtusernameuser.Text = ""
        txtpwuser.Text = ""
        txtnmuser.Text = ""
        txtemailuser.Text = ""
        txttlpuser.Text = ""
        txtalmtuser.Text = ""
        txtusrid.Visible = False
    End Sub
    Private Sub formregistrasi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisiawalregis()
        Call autoiduser()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnbtlregist.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btndaftar.Click
        If txtusernameuser.Text = "" Or txtpwuser.Text = "" Or txtnmuser.Text = "" Or txtemailuser.Text = "" Or txttlpuser.Text = "" Or txtalmtuser.Text = "" Then
            MsgBox("Data Belum Lengkap..!", vbInformation, "GAGAL!")
        Else

            Call koneksi()
            Dim ADD As String = "insert into tbl_user (UserID, Username, Password, Nama, Email, Telp, Alamat) values('" & txtusrid.Text & "','" & txtusernameuser.Text & "','" & txtpwuser.Text & "','" & txtnmuser.Text & "','" & txtemailuser.Text & "','" & txttlpuser.Text & "','" & txtalmtuser.Text & "')"
            cmd = New SqlCommand(ADD, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan!", vbInformation, "SUKSES!")
            Call kondisiawalregis()
            conn.Close()
            Me.Close()
        End If
    End Sub

    Private Sub txtusernameuser_TextChanged(sender As Object, e As EventArgs) Handles txtusernameuser.TextChanged

    End Sub

    Private Sub txtusrid_TextChanged(sender As Object, e As EventArgs) Handles txtusrid.TextChanged

    End Sub
End Class