﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtdummyid = New System.Windows.Forms.TextBox()
        Me.dgvmu = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlNav = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblcoba = New System.Windows.Forms.Label()
        Me.pnlSide = New System.Windows.Forms.Panel()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pnltranspinjam = New System.Windows.Forms.Panel()
        Me.lbljmlpinjam = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.txtnmusrpnjm = New System.Windows.Forms.TextBox()
        Me.txtktgrpnjm = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.txtjdlpnjm = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtbkidpnjm = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtusridpnjm = New System.Windows.Forms.TextBox()
        Me.txtkdpnjm = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dgvkranjang = New System.Windows.Forms.DataGridView()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.pnldataBuku = New System.Windows.Forms.Panel()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.txtrtgdt = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.ptbbkdt = New System.Windows.Forms.PictureBox()
        Me.txtthntrbtdt = New System.Windows.Forms.TextBox()
        Me.txtpnrbtdt = New System.Windows.Forms.TextBox()
        Me.txtpnlsdt = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtktgdt = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtjdldt = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtidbkdt = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.pnlDataDiri = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.txtalmtdb = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txttlpdb = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtemldb = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtnmdb = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtpwdb = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtusrnmdb = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtuseriddb = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.pnlKoleksi = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.dgvkoleksi = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Column5 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.pnlMain.SuspendLayout()
        CType(Me.dgvmu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlNav.SuspendLayout()
        Me.pnlSide.SuspendLayout()
        Me.pnltranspinjam.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvkranjang, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnldataBuku.SuspendLayout()
        CType(Me.ptbbkdt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlDataDiri.SuspendLayout()
        Me.pnlKoleksi.SuspendLayout()
        CType(Me.dgvkoleksi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlMain
        '
        Me.pnlMain.Controls.Add(Me.Label5)
        Me.pnlMain.Controls.Add(Me.Label3)
        Me.pnlMain.Controls.Add(Me.txtdummyid)
        Me.pnlMain.Controls.Add(Me.dgvmu)
        Me.pnlMain.Controls.Add(Me.Label1)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(292, 100)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(975, 596)
        Me.pnlMain.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(268, 127)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(438, 17)
        Me.Label5.TabIndex = 17
        Me.Label5.Tag = "0"
        Me.Label5.Text = """Fabula Library, siap melayani anda dengan sepenuh hati"" "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 237)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(140, 20)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Peminjaman Saya:"
        '
        'txtdummyid
        '
        Me.txtdummyid.Enabled = False
        Me.txtdummyid.Location = New System.Drawing.Point(175, 17)
        Me.txtdummyid.Name = "txtdummyid"
        Me.txtdummyid.Size = New System.Drawing.Size(120, 26)
        Me.txtdummyid.TabIndex = 14
        '
        'dgvmu
        '
        Me.dgvmu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvmu.Location = New System.Drawing.Point(29, 272)
        Me.dgvmu.Name = "dgvmu"
        Me.dgvmu.RowHeadersWidth = 62
        Me.dgvmu.RowTemplate.Height = 28
        Me.dgvmu.Size = New System.Drawing.Size(920, 299)
        Me.dgvmu.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(32, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Tag = "0"
        Me.Label1.Text = "MENU UTAMA"
        '
        'pnlNav
        '
        Me.pnlNav.BackColor = System.Drawing.Color.LightBlue
        Me.pnlNav.Controls.Add(Me.Label6)
        Me.pnlNav.Controls.Add(Me.lblcoba)
        Me.pnlNav.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlNav.Location = New System.Drawing.Point(292, 0)
        Me.pnlNav.Name = "pnlNav"
        Me.pnlNav.Size = New System.Drawing.Size(975, 100)
        Me.pnlNav.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(151, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(18, 20)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "p"
        '
        'lblcoba
        '
        Me.lblcoba.AutoSize = True
        Me.lblcoba.Location = New System.Drawing.Point(24, 43)
        Me.lblcoba.Name = "lblcoba"
        Me.lblcoba.Size = New System.Drawing.Size(129, 20)
        Me.lblcoba.TabIndex = 0
        Me.lblcoba.Text = "Selamat Datang,"
        '
        'pnlSide
        '
        Me.pnlSide.BackColor = System.Drawing.Color.SteelBlue
        Me.pnlSide.Controls.Add(Me.Button15)
        Me.pnlSide.Controls.Add(Me.Button7)
        Me.pnlSide.Controls.Add(Me.Button6)
        Me.pnlSide.Controls.Add(Me.Button4)
        Me.pnlSide.Controls.Add(Me.Button2)
        Me.pnlSide.Controls.Add(Me.Button1)
        Me.pnlSide.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSide.Location = New System.Drawing.Point(0, 0)
        Me.pnlSide.Name = "pnlSide"
        Me.pnlSide.Size = New System.Drawing.Size(292, 696)
        Me.pnlSide.TabIndex = 8
        '
        'Button15
        '
        Me.Button15.FlatAppearance.BorderSize = 0
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.ForeColor = System.Drawing.Color.White
        Me.Button15.Location = New System.Drawing.Point(0, 104)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(292, 52)
        Me.Button15.TabIndex = 6
        Me.Button15.Text = "DATA SAYA"
        Me.Button15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(0, 0)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(292, 100)
        Me.Button7.TabIndex = 5
        Me.Button7.Text = "MENU UTAMA"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(0, 634)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(292, 59)
        Me.Button6.TabIndex = 4
        Me.Button6.Text = "KELUAR"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(0, 270)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(292, 52)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "KOLEKSI SAYA"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(0, 215)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(292, 52)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "PEMINJAMAN"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(0, 159)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(292, 52)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "DATA BUKU"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'pnltranspinjam
        '
        Me.pnltranspinjam.Controls.Add(Me.lbljmlpinjam)
        Me.pnltranspinjam.Controls.Add(Me.DateTimePicker2)
        Me.pnltranspinjam.Controls.Add(Me.DateTimePicker1)
        Me.pnltranspinjam.Controls.Add(Me.Button14)
        Me.pnltranspinjam.Controls.Add(Me.PictureBox1)
        Me.pnltranspinjam.Controls.Add(Me.Button11)
        Me.pnltranspinjam.Controls.Add(Me.txtnmusrpnjm)
        Me.pnltranspinjam.Controls.Add(Me.txtktgrpnjm)
        Me.pnltranspinjam.Controls.Add(Me.Label2)
        Me.pnltranspinjam.Controls.Add(Me.Button9)
        Me.pnltranspinjam.Controls.Add(Me.Button10)
        Me.pnltranspinjam.Controls.Add(Me.txtjdlpnjm)
        Me.pnltranspinjam.Controls.Add(Me.Label10)
        Me.pnltranspinjam.Controls.Add(Me.txtbkidpnjm)
        Me.pnltranspinjam.Controls.Add(Me.Label11)
        Me.pnltranspinjam.Controls.Add(Me.Label12)
        Me.pnltranspinjam.Controls.Add(Me.Label13)
        Me.pnltranspinjam.Controls.Add(Me.txtusridpnjm)
        Me.pnltranspinjam.Controls.Add(Me.txtkdpnjm)
        Me.pnltranspinjam.Controls.Add(Me.Label15)
        Me.pnltranspinjam.Controls.Add(Me.dgvkranjang)
        Me.pnltranspinjam.Controls.Add(Me.Label17)
        Me.pnltranspinjam.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnltranspinjam.Location = New System.Drawing.Point(292, 100)
        Me.pnltranspinjam.Name = "pnltranspinjam"
        Me.pnltranspinjam.Size = New System.Drawing.Size(975, 596)
        Me.pnltranspinjam.TabIndex = 11
        '
        'lbljmlpinjam
        '
        Me.lbljmlpinjam.AutoSize = True
        Me.lbljmlpinjam.Location = New System.Drawing.Point(772, 486)
        Me.lbljmlpinjam.Name = "lbljmlpinjam"
        Me.lbljmlpinjam.Size = New System.Drawing.Size(18, 20)
        Me.lbljmlpinjam.TabIndex = 1
        Me.lbljmlpinjam.Text = "p"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Enabled = False
        Me.DateTimePicker2.Location = New System.Drawing.Point(238, 137)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(249, 26)
        Me.DateTimePicker2.TabIndex = 35
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(238, 96)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(249, 26)
        Me.DateTimePicker1.TabIndex = 34
        '
        'Button14
        '
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.ForeColor = System.Drawing.Color.Black
        Me.Button14.Location = New System.Drawing.Point(700, 166)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(86, 37)
        Me.Button14.TabIndex = 33
        Me.Button14.Text = "RESET"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.barunihuser.My.Resources.Resources.icons8_search_100
        Me.PictureBox1.Location = New System.Drawing.Point(905, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(41, 26)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 32
        Me.PictureBox1.TabStop = False
        '
        'Button11
        '
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.ForeColor = System.Drawing.Color.Black
        Me.Button11.Location = New System.Drawing.Point(822, 478)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(127, 37)
        Me.Button11.TabIndex = 31
        Me.Button11.Text = "PINJAM"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'txtnmusrpnjm
        '
        Me.txtnmusrpnjm.Location = New System.Drawing.Point(6, 178)
        Me.txtnmusrpnjm.Name = "txtnmusrpnjm"
        Me.txtnmusrpnjm.Size = New System.Drawing.Size(71, 26)
        Me.txtnmusrpnjm.TabIndex = 30
        '
        'txtktgrpnjm
        '
        Me.txtktgrpnjm.Enabled = False
        Me.txtktgrpnjm.Location = New System.Drawing.Point(717, 130)
        Me.txtktgrpnjm.Name = "txtktgrpnjm"
        Me.txtktgrpnjm.Size = New System.Drawing.Size(229, 26)
        Me.txtktgrpnjm.TabIndex = 28
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(513, 130)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(184, 28)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Kategori:"
        '
        'Button9
        '
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.ForeColor = System.Drawing.Color.Black
        Me.Button9.Location = New System.Drawing.Point(559, 478)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(199, 37)
        Me.Button9.TabIndex = 26
        Me.Button9.Text = "PEMINJAMAN SAYA:"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.ForeColor = System.Drawing.Color.Black
        Me.Button10.Location = New System.Drawing.Point(796, 166)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(150, 37)
        Me.Button10.TabIndex = 6
        Me.Button10.Text = "TAMBAHKAN"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'txtjdlpnjm
        '
        Me.txtjdlpnjm.Enabled = False
        Me.txtjdlpnjm.Location = New System.Drawing.Point(717, 94)
        Me.txtjdlpnjm.Name = "txtjdlpnjm"
        Me.txtjdlpnjm.Size = New System.Drawing.Size(229, 26)
        Me.txtjdlpnjm.TabIndex = 23
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Location = New System.Drawing.Point(513, 94)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(184, 28)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Judul:"
        '
        'txtbkidpnjm
        '
        Me.txtbkidpnjm.Enabled = False
        Me.txtbkidpnjm.Location = New System.Drawing.Point(717, 56)
        Me.txtbkidpnjm.Name = "txtbkidpnjm"
        Me.txtbkidpnjm.Size = New System.Drawing.Size(182, 26)
        Me.txtbkidpnjm.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Location = New System.Drawing.Point(513, 56)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(184, 28)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Buku ID:"
        '
        'Label12
        '
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label12.Location = New System.Drawing.Point(28, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(184, 28)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Tenggat:"
        '
        'Label13
        '
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label13.Location = New System.Drawing.Point(29, 96)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(183, 27)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Tanggal Peminjaman:"
        '
        'txtusridpnjm
        '
        Me.txtusridpnjm.Location = New System.Drawing.Point(6, 142)
        Me.txtusridpnjm.Name = "txtusridpnjm"
        Me.txtusridpnjm.Size = New System.Drawing.Size(71, 26)
        Me.txtusridpnjm.TabIndex = 15
        '
        'txtkdpnjm
        '
        Me.txtkdpnjm.Enabled = False
        Me.txtkdpnjm.Location = New System.Drawing.Point(238, 59)
        Me.txtkdpnjm.Name = "txtkdpnjm"
        Me.txtkdpnjm.Size = New System.Drawing.Size(249, 26)
        Me.txtkdpnjm.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Location = New System.Drawing.Point(28, 58)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(183, 27)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Kode Transaksi:"
        '
        'dgvkranjang
        '
        Me.dgvkranjang.AllowUserToAddRows = False
        Me.dgvkranjang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvkranjang.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column2, Me.Column3, Me.Column4, Me.Column1})
        Me.dgvkranjang.Location = New System.Drawing.Point(28, 209)
        Me.dgvkranjang.Name = "dgvkranjang"
        Me.dgvkranjang.RowHeadersWidth = 62
        Me.dgvkranjang.RowTemplate.Height = 28
        Me.dgvkranjang.Size = New System.Drawing.Size(920, 263)
        Me.dgvkranjang.TabIndex = 11
        '
        'Column2
        '
        Me.Column2.HeaderText = "Buku ID"
        Me.Column2.MinimumWidth = 8
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 150
        '
        'Column3
        '
        Me.Column3.HeaderText = "Judul"
        Me.Column3.MinimumWidth = 8
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 150
        '
        'Column4
        '
        Me.Column4.HeaderText = "Kategori"
        Me.Column4.MinimumWidth = 8
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 150
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column1.HeaderText = "Hapus"
        Me.Column1.MinimumWidth = 8
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Text = "Hapus"
        Me.Column1.ToolTipText = "Hapus"
        Me.Column1.UseColumnTextForButtonValue = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(32, 26)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(123, 20)
        Me.Label17.TabIndex = 6
        Me.Label17.Tag = "0"
        Me.Label17.Text = "PEMINJAMAN"
        '
        'pnldataBuku
        '
        Me.pnldataBuku.Controls.Add(Me.Button13)
        Me.pnldataBuku.Controls.Add(Me.TextBox5)
        Me.pnldataBuku.Controls.Add(Me.Label18)
        Me.pnldataBuku.Controls.Add(Me.Button12)
        Me.pnldataBuku.Controls.Add(Me.txtrtgdt)
        Me.pnldataBuku.Controls.Add(Me.Label19)
        Me.pnldataBuku.Controls.Add(Me.ptbbkdt)
        Me.pnldataBuku.Controls.Add(Me.txtthntrbtdt)
        Me.pnldataBuku.Controls.Add(Me.txtpnrbtdt)
        Me.pnldataBuku.Controls.Add(Me.txtpnlsdt)
        Me.pnldataBuku.Controls.Add(Me.Label20)
        Me.pnldataBuku.Controls.Add(Me.Label21)
        Me.pnldataBuku.Controls.Add(Me.Label23)
        Me.pnldataBuku.Controls.Add(Me.txtktgdt)
        Me.pnldataBuku.Controls.Add(Me.Label24)
        Me.pnldataBuku.Controls.Add(Me.txtjdldt)
        Me.pnldataBuku.Controls.Add(Me.Label25)
        Me.pnldataBuku.Controls.Add(Me.txtidbkdt)
        Me.pnldataBuku.Controls.Add(Me.Label26)
        Me.pnldataBuku.Controls.Add(Me.DataGridView1)
        Me.pnldataBuku.Controls.Add(Me.Label27)
        Me.pnldataBuku.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnldataBuku.Location = New System.Drawing.Point(292, 100)
        Me.pnldataBuku.Name = "pnldataBuku"
        Me.pnldataBuku.Size = New System.Drawing.Size(975, 596)
        Me.pnldataBuku.TabIndex = 12
        '
        'Button13
        '
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.ForeColor = System.Drawing.Color.Black
        Me.Button13.Location = New System.Drawing.Point(812, 236)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(134, 32)
        Me.Button13.TabIndex = 67
        Me.Button13.Text = "PINJAM"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(161, 242)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(629, 26)
        Me.TextBox5.TabIndex = 66
        '
        'Label18
        '
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label18.Location = New System.Drawing.Point(29, 241)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(126, 28)
        Me.Label18.TabIndex = 65
        Me.Label18.Text = "Cari:"
        '
        'Button12
        '
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.ForeColor = System.Drawing.Color.Black
        Me.Button12.Location = New System.Drawing.Point(423, 195)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(367, 32)
        Me.Button12.TabIndex = 64
        Me.Button12.Text = "Lihat Ulasan Buku"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'txtrtgdt
        '
        Me.txtrtgdt.Enabled = False
        Me.txtrtgdt.Location = New System.Drawing.Point(560, 155)
        Me.txtrtgdt.Name = "txtrtgdt"
        Me.txtrtgdt.Size = New System.Drawing.Size(229, 26)
        Me.txtrtgdt.TabIndex = 63
        '
        'Label19
        '
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label19.Location = New System.Drawing.Point(423, 153)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(126, 28)
        Me.Label19.TabIndex = 62
        Me.Label19.Text = "Rating:"
        '
        'ptbbkdt
        '
        Me.ptbbkdt.Location = New System.Drawing.Point(812, 66)
        Me.ptbbkdt.Name = "ptbbkdt"
        Me.ptbbkdt.Size = New System.Drawing.Size(134, 160)
        Me.ptbbkdt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ptbbkdt.TabIndex = 61
        Me.ptbbkdt.TabStop = False
        '
        'txtthntrbtdt
        '
        Me.txtthntrbtdt.Enabled = False
        Me.txtthntrbtdt.Location = New System.Drawing.Point(560, 111)
        Me.txtthntrbtdt.Name = "txtthntrbtdt"
        Me.txtthntrbtdt.Size = New System.Drawing.Size(229, 26)
        Me.txtthntrbtdt.TabIndex = 60
        '
        'txtpnrbtdt
        '
        Me.txtpnrbtdt.Enabled = False
        Me.txtpnrbtdt.Location = New System.Drawing.Point(560, 67)
        Me.txtpnrbtdt.Name = "txtpnrbtdt"
        Me.txtpnrbtdt.Size = New System.Drawing.Size(230, 26)
        Me.txtpnrbtdt.TabIndex = 59
        '
        'txtpnlsdt
        '
        Me.txtpnlsdt.Enabled = False
        Me.txtpnlsdt.Location = New System.Drawing.Point(167, 201)
        Me.txtpnlsdt.Name = "txtpnlsdt"
        Me.txtpnlsdt.Size = New System.Drawing.Size(229, 26)
        Me.txtpnlsdt.TabIndex = 58
        '
        'Label20
        '
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Location = New System.Drawing.Point(423, 109)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(126, 28)
        Me.Label20.TabIndex = 57
        Me.Label20.Text = "Tahun Terbit:"
        '
        'Label21
        '
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Location = New System.Drawing.Point(423, 66)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(126, 28)
        Me.Label21.TabIndex = 56
        Me.Label21.Text = "Penerbit:"
        '
        'Label23
        '
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label23.Location = New System.Drawing.Point(30, 198)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(126, 28)
        Me.Label23.TabIndex = 55
        Me.Label23.Text = "Penulis:"
        '
        'txtktgdt
        '
        Me.txtktgdt.Enabled = False
        Me.txtktgdt.Location = New System.Drawing.Point(167, 157)
        Me.txtktgdt.Name = "txtktgdt"
        Me.txtktgdt.Size = New System.Drawing.Size(229, 26)
        Me.txtktgdt.TabIndex = 54
        '
        'Label24
        '
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Location = New System.Drawing.Point(30, 155)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(126, 28)
        Me.Label24.TabIndex = 53
        Me.Label24.Text = "Kategori:"
        '
        'txtjdldt
        '
        Me.txtjdldt.Enabled = False
        Me.txtjdldt.Location = New System.Drawing.Point(167, 113)
        Me.txtjdldt.Name = "txtjdldt"
        Me.txtjdldt.Size = New System.Drawing.Size(229, 26)
        Me.txtjdldt.TabIndex = 52
        '
        'Label25
        '
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(30, 111)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(126, 28)
        Me.Label25.TabIndex = 51
        Me.Label25.Text = "Judul:"
        '
        'txtidbkdt
        '
        Me.txtidbkdt.Enabled = False
        Me.txtidbkdt.Location = New System.Drawing.Point(167, 68)
        Me.txtidbkdt.Name = "txtidbkdt"
        Me.txtidbkdt.Size = New System.Drawing.Size(229, 26)
        Me.txtidbkdt.TabIndex = 50
        '
        'Label26
        '
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Location = New System.Drawing.Point(30, 66)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(126, 28)
        Me.Label26.TabIndex = 49
        Me.Label26.Text = "Buku ID:"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(29, 276)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(920, 305)
        Me.DataGridView1.TabIndex = 48
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(32, 26)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(110, 20)
        Me.Label27.TabIndex = 6
        Me.Label27.Tag = "0"
        Me.Label27.Text = "DATA BUKU"
        '
        'pnlDataDiri
        '
        Me.pnlDataDiri.Controls.Add(Me.Button5)
        Me.pnlDataDiri.Controls.Add(Me.txtalmtdb)
        Me.pnlDataDiri.Controls.Add(Me.Label14)
        Me.pnlDataDiri.Controls.Add(Me.txttlpdb)
        Me.pnlDataDiri.Controls.Add(Me.Label16)
        Me.pnlDataDiri.Controls.Add(Me.txtemldb)
        Me.pnlDataDiri.Controls.Add(Me.Label28)
        Me.pnlDataDiri.Controls.Add(Me.txtnmdb)
        Me.pnlDataDiri.Controls.Add(Me.Label29)
        Me.pnlDataDiri.Controls.Add(Me.txtpwdb)
        Me.pnlDataDiri.Controls.Add(Me.Label30)
        Me.pnlDataDiri.Controls.Add(Me.txtusrnmdb)
        Me.pnlDataDiri.Controls.Add(Me.Label31)
        Me.pnlDataDiri.Controls.Add(Me.txtuseriddb)
        Me.pnlDataDiri.Controls.Add(Me.Label32)
        Me.pnlDataDiri.Controls.Add(Me.Label34)
        Me.pnlDataDiri.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlDataDiri.Location = New System.Drawing.Point(292, 100)
        Me.pnlDataDiri.Name = "pnlDataDiri"
        Me.pnlDataDiri.Size = New System.Drawing.Size(975, 596)
        Me.pnlDataDiri.TabIndex = 13
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(700, 546)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(246, 37)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "EDIT"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'txtalmtdb
        '
        Me.txtalmtdb.Enabled = False
        Me.txtalmtdb.Location = New System.Drawing.Point(318, 428)
        Me.txtalmtdb.Multiline = True
        Me.txtalmtdb.Name = "txtalmtdb"
        Me.txtalmtdb.Size = New System.Drawing.Size(628, 110)
        Me.txtalmtdb.TabIndex = 25
        '
        'Label14
        '
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Location = New System.Drawing.Point(29, 430)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(255, 28)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "Alamat:"
        '
        'txttlpdb
        '
        Me.txttlpdb.Enabled = False
        Me.txttlpdb.Location = New System.Drawing.Point(318, 363)
        Me.txttlpdb.Name = "txttlpdb"
        Me.txttlpdb.Size = New System.Drawing.Size(628, 26)
        Me.txttlpdb.TabIndex = 23
        '
        'Label16
        '
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Location = New System.Drawing.Point(29, 365)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(255, 28)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Telp:"
        '
        'txtemldb
        '
        Me.txtemldb.Enabled = False
        Me.txtemldb.Location = New System.Drawing.Point(318, 304)
        Me.txtemldb.Name = "txtemldb"
        Me.txtemldb.Size = New System.Drawing.Size(628, 26)
        Me.txtemldb.TabIndex = 21
        '
        'Label28
        '
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label28.Location = New System.Drawing.Point(29, 306)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(255, 28)
        Me.Label28.TabIndex = 20
        Me.Label28.Text = "Email:"
        '
        'txtnmdb
        '
        Me.txtnmdb.Enabled = False
        Me.txtnmdb.Location = New System.Drawing.Point(318, 244)
        Me.txtnmdb.Name = "txtnmdb"
        Me.txtnmdb.Size = New System.Drawing.Size(628, 26)
        Me.txtnmdb.TabIndex = 19
        '
        'Label29
        '
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Location = New System.Drawing.Point(29, 246)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(255, 28)
        Me.Label29.TabIndex = 18
        Me.Label29.Text = "Nama:"
        '
        'txtpwdb
        '
        Me.txtpwdb.Enabled = False
        Me.txtpwdb.Location = New System.Drawing.Point(318, 184)
        Me.txtpwdb.Name = "txtpwdb"
        Me.txtpwdb.Size = New System.Drawing.Size(628, 26)
        Me.txtpwdb.TabIndex = 17
        '
        'Label30
        '
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label30.Location = New System.Drawing.Point(29, 186)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(255, 27)
        Me.Label30.TabIndex = 16
        Me.Label30.Text = "Password:"
        '
        'txtusrnmdb
        '
        Me.txtusrnmdb.Enabled = False
        Me.txtusrnmdb.Location = New System.Drawing.Point(318, 126)
        Me.txtusrnmdb.Name = "txtusrnmdb"
        Me.txtusrnmdb.Size = New System.Drawing.Size(628, 26)
        Me.txtusrnmdb.TabIndex = 15
        '
        'Label31
        '
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label31.Location = New System.Drawing.Point(29, 128)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(255, 27)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "Username:"
        '
        'txtuseriddb
        '
        Me.txtuseriddb.Enabled = False
        Me.txtuseriddb.Location = New System.Drawing.Point(318, 72)
        Me.txtuseriddb.Name = "txtuseriddb"
        Me.txtuseriddb.Size = New System.Drawing.Size(628, 26)
        Me.txtuseriddb.TabIndex = 13
        '
        'Label32
        '
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label32.Location = New System.Drawing.Point(29, 74)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(255, 27)
        Me.Label32.TabIndex = 12
        Me.Label32.Text = "User ID:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(32, 26)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(109, 20)
        Me.Label34.TabIndex = 6
        Me.Label34.Tag = "0"
        Me.Label34.Text = "DATA SAYA"
        '
        'pnlKoleksi
        '
        Me.pnlKoleksi.Controls.Add(Me.TextBox1)
        Me.pnlKoleksi.Controls.Add(Me.dgvkoleksi)
        Me.pnlKoleksi.Controls.Add(Me.Label4)
        Me.pnlKoleksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlKoleksi.Location = New System.Drawing.Point(292, 100)
        Me.pnlKoleksi.Name = "pnlKoleksi"
        Me.pnlKoleksi.Size = New System.Drawing.Size(975, 596)
        Me.pnlKoleksi.TabIndex = 14
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(216, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 26)
        Me.TextBox1.TabIndex = 12
        '
        'dgvkoleksi
        '
        Me.dgvkoleksi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvkoleksi.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column5})
        Me.dgvkoleksi.Location = New System.Drawing.Point(36, 56)
        Me.dgvkoleksi.Name = "dgvkoleksi"
        Me.dgvkoleksi.RowHeadersWidth = 62
        Me.dgvkoleksi.RowTemplate.Height = 28
        Me.dgvkoleksi.Size = New System.Drawing.Size(920, 515)
        Me.dgvkoleksi.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(32, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(137, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Tag = "0"
        Me.Label4.Text = "KOLEKSI SAYA"
        '
        'Column5
        '
        Me.Column5.HeaderText = "BeriUlasan"
        Me.Column5.MinimumWidth = 8
        Me.Column5.Name = "Column5"
        Me.Column5.Text = "Beri Ulasan"
        Me.Column5.UseColumnTextForButtonValue = True
        Me.Column5.Width = 150
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1267, 696)
        Me.ControlBox = False
        Me.Controls.Add(Me.pnltranspinjam)
        Me.Controls.Add(Me.pnldataBuku)
        Me.Controls.Add(Me.pnlKoleksi)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.pnlDataDiri)
        Me.Controls.Add(Me.pnlNav)
        Me.Controls.Add(Me.pnlSide)
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DASHBOARD"
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        CType(Me.dgvmu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlNav.ResumeLayout(False)
        Me.pnlNav.PerformLayout()
        Me.pnlSide.ResumeLayout(False)
        Me.pnltranspinjam.ResumeLayout(False)
        Me.pnltranspinjam.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvkranjang, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnldataBuku.ResumeLayout(False)
        Me.pnldataBuku.PerformLayout()
        CType(Me.ptbbkdt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlDataDiri.ResumeLayout(False)
        Me.pnlDataDiri.PerformLayout()
        Me.pnlKoleksi.ResumeLayout(False)
        Me.pnlKoleksi.PerformLayout()
        CType(Me.dgvkoleksi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlMain As Panel
    Friend WithEvents dgvmu As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlNav As Panel
    Friend WithEvents lblcoba As Label
    Friend WithEvents pnlSide As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents pnltranspinjam As Panel
    Friend WithEvents Button11 As Button
    Friend WithEvents txtnmusrpnjm As TextBox
    Friend WithEvents txtktgrpnjm As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents txtjdlpnjm As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtbkidpnjm As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents txtusridpnjm As TextBox
    Friend WithEvents txtkdpnjm As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents dgvkranjang As DataGridView
    Friend WithEvents Label17 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents pnldataBuku As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Button12 As Button
    Friend WithEvents txtrtgdt As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents ptbbkdt As PictureBox
    Friend WithEvents txtthntrbtdt As TextBox
    Friend WithEvents txtpnrbtdt As TextBox
    Friend WithEvents txtpnlsdt As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents txtktgdt As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtjdldt As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents txtidbkdt As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents DateTimePicker2 As DateTimePicker
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Button15 As Button
    Friend WithEvents pnlDataDiri As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents txtalmtdb As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txttlpdb As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtemldb As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents txtnmdb As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents txtpwdb As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtusrnmdb As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents txtuseriddb As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents pnlKoleksi As Panel
    Friend WithEvents dgvkoleksi As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents lbljmlpinjam As Label
    Friend WithEvents txtdummyid As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewButtonColumn
    Friend WithEvents Column5 As DataGridViewButtonColumn
End Class
