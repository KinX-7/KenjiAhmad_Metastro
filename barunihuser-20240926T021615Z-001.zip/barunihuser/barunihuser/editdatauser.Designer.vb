﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class editdatauser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtpwedt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtusrnmedt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txttlpedt = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtemledt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtnmedt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtalmtedt = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtidedt = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtpwedt
        '
        Me.txtpwedt.Location = New System.Drawing.Point(133, 127)
        Me.txtpwedt.Name = "txtpwedt"
        Me.txtpwedt.Size = New System.Drawing.Size(248, 26)
        Me.txtpwedt.TabIndex = 21
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(19, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 27)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Password:"
        '
        'txtusrnmedt
        '
        Me.txtusrnmedt.Location = New System.Drawing.Point(133, 77)
        Me.txtusrnmedt.Name = "txtusrnmedt"
        Me.txtusrnmedt.Size = New System.Drawing.Size(248, 26)
        Me.txtusrnmedt.TabIndex = 19
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(19, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 27)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Username:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 20)
        Me.Label1.TabIndex = 22
        Me.Label1.Tag = "0"
        Me.Label1.Text = "EDIT DATA PRIBADI"
        '
        'txttlpedt
        '
        Me.txttlpedt.Location = New System.Drawing.Point(133, 279)
        Me.txttlpedt.Name = "txttlpedt"
        Me.txttlpedt.Size = New System.Drawing.Size(248, 26)
        Me.txttlpedt.TabIndex = 29
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Location = New System.Drawing.Point(19, 278)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 28)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "Telp:"
        '
        'txtemledt
        '
        Me.txtemledt.Location = New System.Drawing.Point(133, 229)
        Me.txtemledt.Name = "txtemledt"
        Me.txtemledt.Size = New System.Drawing.Size(248, 26)
        Me.txtemledt.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(19, 228)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 28)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Email:"
        '
        'txtnmedt
        '
        Me.txtnmedt.Location = New System.Drawing.Point(133, 178)
        Me.txtnmedt.Name = "txtnmedt"
        Me.txtnmedt.Size = New System.Drawing.Size(248, 26)
        Me.txtnmedt.TabIndex = 25
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(19, 177)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 28)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Nama:"
        '
        'txtalmtedt
        '
        Me.txtalmtedt.Location = New System.Drawing.Point(133, 324)
        Me.txtalmtedt.Multiline = True
        Me.txtalmtedt.Name = "txtalmtedt"
        Me.txtalmtedt.Size = New System.Drawing.Size(248, 100)
        Me.txtalmtedt.TabIndex = 31
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(19, 326)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 28)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Alamat:"
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(282, 449)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(99, 37)
        Me.Button5.TabIndex = 32
        Me.Button5.Text = "SIMPAN"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(154, 449)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 37)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "RESET"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(19, 449)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 37)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "CANCEL"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtidedt
        '
        Me.txtidedt.Location = New System.Drawing.Point(232, 19)
        Me.txtidedt.Name = "txtidedt"
        Me.txtidedt.Size = New System.Drawing.Size(149, 26)
        Me.txtidedt.TabIndex = 35
        '
        'editdatauser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 505)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtidedt)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.txtalmtedt)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txttlpedt)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtemledt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtnmedt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtpwedt)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtusrnmedt)
        Me.Controls.Add(Me.Label4)
        Me.Name = "editdatauser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtpwedt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtusrnmedt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txttlpedt As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtemledt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtnmedt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtalmtedt As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents txtidedt As TextBox
End Class
