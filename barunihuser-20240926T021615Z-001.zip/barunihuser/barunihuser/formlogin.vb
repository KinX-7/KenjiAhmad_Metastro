﻿Imports System.Data.SqlClient
Public Class formlogin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Call koneksi()
        cmd = New SqlCommand("select * from tbl_user where Username= '" & TextBox1.Text & "' and Password= '" & TextBox2.Text & "'", conn)
        rd = cmd.ExecuteReader
        rd.Read()
        If rd.HasRows Then
            ProgressBar.Timer1.Enabled = True
            Me.Hide()
            progressbar.Show()
            Dim username = TextBox1.Text
        Else
            MsgBox("Username atau Password Salah!", vbInformation, "GAGAL!")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox1.Focus()
        End If

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        formregistrasi.ShowDialog()
    End Sub

    Private Sub formlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub
End Class
