﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UlasanBuku
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtulsn = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtrting = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtusrid = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 245)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(465, 310)
        Me.DataGridView1.TabIndex = 0
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(8, 9)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(134, 20)
        Me.Label27.TabIndex = 7
        Me.Label27.Tag = "0"
        Me.Label27.Text = "ULASAN BUKU"
        '
        'txtulsn
        '
        Me.txtulsn.Enabled = False
        Me.txtulsn.Location = New System.Drawing.Point(148, 130)
        Me.txtulsn.Multiline = True
        Me.txtulsn.Name = "txtulsn"
        Me.txtulsn.Size = New System.Drawing.Size(329, 98)
        Me.txtulsn.TabIndex = 66
        '
        'Label23
        '
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label23.Location = New System.Drawing.Point(11, 130)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(126, 28)
        Me.Label23.TabIndex = 65
        Me.Label23.Text = "Ulasan:"
        '
        'txtrting
        '
        Me.txtrting.Enabled = False
        Me.txtrting.Location = New System.Drawing.Point(148, 88)
        Me.txtrting.Name = "txtrting"
        Me.txtrting.Size = New System.Drawing.Size(329, 26)
        Me.txtrting.TabIndex = 64
        '
        'Label24
        '
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Location = New System.Drawing.Point(11, 87)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(126, 28)
        Me.Label24.TabIndex = 63
        Me.Label24.Text = "Rating"
        '
        'txtusrid
        '
        Me.txtusrid.Enabled = False
        Me.txtusrid.Location = New System.Drawing.Point(148, 44)
        Me.txtusrid.Name = "txtusrid"
        Me.txtusrid.Size = New System.Drawing.Size(329, 26)
        Me.txtusrid.TabIndex = 62
        '
        'Label25
        '
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(11, 43)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(126, 28)
        Me.Label25.TabIndex = 61
        Me.Label25.Text = "User ID:"
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(378, 561)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(99, 37)
        Me.Button5.TabIndex = 67
        Me.Button5.Text = "TUTUP"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'UlasanBuku
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(493, 605)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.txtulsn)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtrting)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtusrid)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "UlasanBuku"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label27 As Label
    Friend WithEvents txtulsn As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtrting As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtusrid As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Button5 As Button
End Class
