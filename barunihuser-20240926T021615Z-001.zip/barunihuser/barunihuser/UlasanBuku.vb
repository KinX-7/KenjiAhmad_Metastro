﻿Imports System.Data.SqlClient
Public Class UlasanBuku
    Sub kondisi()
        Call koneksi()
        da = New SqlDataAdapter("select Rating, Ulasan from tbl_ulasan where BukuID like '%" & Dashboard.txtidbkdt.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_ulasan")
        DataGridView1.DataSource = (ds.Tables("tbl_ulasan"))
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub
    Private Sub Label27_Click(sender As Object, e As EventArgs) Handles Label27.Click

    End Sub

    Private Sub UlasanBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisi()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Hide()
    End Sub
    'Public Sub userdata()
    '    Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
    '    Dim query As String = "SELECT UserID FROM tbl_user WHERE UserID = @Username"

    '    Using connection As New SqlConnection(connectionString)
    '        Dim command As New SqlCommand(query, connection)
    '        command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

    '        Try
    '            connection.Open()
    '            Dim reader As SqlDataReader = command.ExecuteReader()

    '            If reader.Read() Then

    '                txtusrid.Text = reader("UserID").ToString()

    '            Else
    '                MessageBox.Show("Data tidak ditemukan")
    '            End If

    '            reader.Close()
    '        Catch ex As Exception
    '            MessageBox.Show("Error: " & ex.Message)
    '        End Try
    '    End Using
    'End Sub
End Class