﻿Imports System.Data.SqlClient
Public Class BeriUlasan
    Sub kondisiawal()
        Call koneksi()
        da = New SqlDataAdapter("Select BukuID, Judul, Kategori, Ulasan, Rating from tbl_koleksi where UserID like '%" & Dashboard.txtuseriddb.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_koleksi")
        Dashboard.dgvkoleksi.DataSource = (ds.Tables("tbl_koleksi"))
        Dashboard.dgvkoleksi.DataSource = ds.Tables(0)
        Dashboard.dgvkoleksi.ReadOnly = True
        Dashboard.dgvkoleksi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill

    End Sub

    Sub updatebuku()
        Call koneksi()
        Dim EDIT As String = "update tbl_buku set Rating='" & NumericUpDown1.Text & "' where BukuID='" & txtbkidulas.Text & "'"
        cmd = New SqlCommand(EDIT, conn)
        cmd.ExecuteNonQuery()
    End Sub
    Sub masukulasan()
        Call koneksi()
        Dim ADD As String = "insert into tbl_ulasan(UserID, BukuID, Ulasan, Rating) values('" & Dashboard.txtuseriddb.Text & "','" & txtbkidulas.Text & "','" & txtulsnulas.Text & "','" & NumericUpDown1.Text & "')"
        cmd = New SqlCommand(ADD, conn)
        cmd.ExecuteNonQuery()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub

    Private Sub BeriUlasan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NumericUpDown1.Minimum = 1
        NumericUpDown1.Maximum = 10
        NumericUpDown1.ReadOnly = True
        For baris As Integer = 0 To Dashboard.dgvkoleksi.Rows.Count - 2
            txtbkidulas.Text = Dashboard.dgvkoleksi.Rows(baris).Cells(1).Value
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtulsnulas.Text = ""
        txtulsnulas.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Call koneksi()
        'Dim EDIT As String = "update tbl_koleksi set Rating='" & NumericUpDown1.Text & "',Ulasan='" & txtulsnulas.Text & "' where BukuID='" & txtbkidulas.Text & "'"
        'cmd = New SqlCommand(EDIT, conn)
        'cmd.ExecuteNonQuery()
        'Call masukulasan()
        'Call updatebuku()
        'Call Dashboard.filterkoleksi()
        'MsgBox("Ulasan dan Rating ditambahkan!", vbInformation, "SUKSES!")
        'txtulsnulas.Text = ""
        'txtbkidulas.Text = ""
        'Me.Close()
        Dim trans As SqlTransaction = Nothing

        Try
            ' Buka koneksi
            Call koneksi()

            ' Mulai transaksi
            trans = conn.BeginTransaction()


            ' Insert ke tabel tbl_ulasan
            Dim addUlasanQuery As String = "INSERT INTO tbl_ulasan (UserID, BukuID, Ulasan, Rating) VALUES (@UserID, @BukuID, @Ulasan, @Rating)"
            Dim addUlasanCmd As New SqlCommand(addUlasanQuery, conn, trans)
            addUlasanCmd.Parameters.AddWithValue("@UserID", Dashboard.txtuseriddb.Text)
            addUlasanCmd.Parameters.AddWithValue("@BukuID", txtbkidulas.Text)
            addUlasanCmd.Parameters.AddWithValue("@Ulasan", txtulsnulas.Text)
            addUlasanCmd.Parameters.AddWithValue("@Rating", NumericUpDown1.Value)
            addUlasanCmd.ExecuteNonQuery()

            ' Update tbl_koleksi
            Dim editKoleksiQuery As String = "UPDATE tbl_koleksi SET Rating = @Rating, Ulasan = @Ulasan WHERE BukuID = @BukuID"
            Dim editKoleksiCmd As New SqlCommand(editKoleksiQuery, conn, trans)
            editKoleksiCmd.Parameters.AddWithValue("@Rating", NumericUpDown1.Value)
            editKoleksiCmd.Parameters.AddWithValue("@Ulasan", txtulsnulas.Text)
            editKoleksiCmd.Parameters.AddWithValue("@BukuID", txtbkidulas.Text)
            editKoleksiCmd.ExecuteNonQuery()

            ' Update tbl_buku
            Dim updateBukuQuery As String = "UPDATE tbl_buku SET Rating = (SELECT AVG(Rating) FROM tbl_ulasan WHERE BukuID = @BukuID) WHERE BukuID = @BukuID"
            Dim updateBukuCmd As New SqlCommand(updateBukuQuery, conn, trans)
            updateBukuCmd.Parameters.AddWithValue("@BukuID", txtbkidulas.Text)
            updateBukuCmd.ExecuteNonQuery()

            ' Commit transaksi jika semua operasi berhasil
            trans.Commit()
            Call kondisiawal()
            ' Tutup koneksi
            conn.Close()
            Me.Close()
            MsgBox("Ulasan dan Rating ditambahkan!")
        Catch ex As Exception
            ' Rollback transaksi jika terjadi kesalahan
            trans.Rollback()

            ' Tangani kesalahan sesuai kebutuhan Anda
            MessageBox.Show("Error: " & ex.Message)

        End Try

    End Sub
End Class