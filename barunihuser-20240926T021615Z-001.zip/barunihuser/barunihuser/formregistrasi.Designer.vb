﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formregistrasi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txttlpuser = New System.Windows.Forms.TextBox()
        Me.txtemailuser = New System.Windows.Forms.TextBox()
        Me.txtnmuser = New System.Windows.Forms.TextBox()
        Me.txtpwuser = New System.Windows.Forms.TextBox()
        Me.txtusernameuser = New System.Windows.Forms.TextBox()
        Me.txtalmtuser = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnbtlregist = New System.Windows.Forms.Button()
        Me.btndaftar = New System.Windows.Forms.Button()
        Me.txtusrid = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(156, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "REGISTRASI"
        '
        'txttlpuser
        '
        Me.txttlpuser.Location = New System.Drawing.Point(149, 385)
        Me.txttlpuser.Name = "txttlpuser"
        Me.txttlpuser.Size = New System.Drawing.Size(244, 26)
        Me.txttlpuser.TabIndex = 32
        '
        'txtemailuser
        '
        Me.txtemailuser.Location = New System.Drawing.Point(149, 318)
        Me.txtemailuser.Name = "txtemailuser"
        Me.txtemailuser.Size = New System.Drawing.Size(244, 26)
        Me.txtemailuser.TabIndex = 31
        '
        'txtnmuser
        '
        Me.txtnmuser.Location = New System.Drawing.Point(149, 250)
        Me.txtnmuser.Name = "txtnmuser"
        Me.txtnmuser.Size = New System.Drawing.Size(244, 26)
        Me.txtnmuser.TabIndex = 30
        '
        'txtpwuser
        '
        Me.txtpwuser.Location = New System.Drawing.Point(149, 181)
        Me.txtpwuser.Name = "txtpwuser"
        Me.txtpwuser.Size = New System.Drawing.Size(244, 26)
        Me.txtpwuser.TabIndex = 29
        '
        'txtusernameuser
        '
        Me.txtusernameuser.Location = New System.Drawing.Point(149, 116)
        Me.txtusernameuser.Name = "txtusernameuser"
        Me.txtusernameuser.Size = New System.Drawing.Size(244, 26)
        Me.txtusernameuser.TabIndex = 28
        '
        'txtalmtuser
        '
        Me.txtalmtuser.Location = New System.Drawing.Point(149, 458)
        Me.txtalmtuser.Multiline = True
        Me.txtalmtuser.Name = "txtalmtuser"
        Me.txtalmtuser.Size = New System.Drawing.Size(244, 123)
        Me.txtalmtuser.TabIndex = 27
        '
        'Label12
        '
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label12.Location = New System.Drawing.Point(25, 386)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 24)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "Telp:"
        '
        'Label13
        '
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label13.Location = New System.Drawing.Point(25, 319)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 24)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Email:"
        '
        'Label14
        '
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Location = New System.Drawing.Point(25, 250)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(104, 24)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "Nama:"
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Location = New System.Drawing.Point(25, 180)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 24)
        Me.Label15.TabIndex = 23
        Me.Label15.Text = "Password:"
        '
        'Label16
        '
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Location = New System.Drawing.Point(25, 115)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(104, 24)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Username:"
        '
        'Label17
        '
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label17.Location = New System.Drawing.Point(25, 458)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(104, 23)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Alamat:"
        '
        'btnbtlregist
        '
        Me.btnbtlregist.Location = New System.Drawing.Point(25, 612)
        Me.btnbtlregist.Name = "btnbtlregist"
        Me.btnbtlregist.Size = New System.Drawing.Size(167, 46)
        Me.btnbtlregist.TabIndex = 33
        Me.btnbtlregist.Text = "BATAL"
        Me.btnbtlregist.UseVisualStyleBackColor = True
        '
        'btndaftar
        '
        Me.btndaftar.Location = New System.Drawing.Point(226, 612)
        Me.btndaftar.Name = "btndaftar"
        Me.btndaftar.Size = New System.Drawing.Size(167, 46)
        Me.btndaftar.TabIndex = 34
        Me.btndaftar.Text = "DAFTAR"
        Me.btndaftar.UseVisualStyleBackColor = True
        '
        'txtusrid
        '
        Me.txtusrid.Enabled = False
        Me.txtusrid.Location = New System.Drawing.Point(174, 12)
        Me.txtusrid.Name = "txtusrid"
        Me.txtusrid.Size = New System.Drawing.Size(244, 26)
        Me.txtusrid.TabIndex = 35
        '
        'formregistrasi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(430, 685)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtusrid)
        Me.Controls.Add(Me.btndaftar)
        Me.Controls.Add(Me.btnbtlregist)
        Me.Controls.Add(Me.txttlpuser)
        Me.Controls.Add(Me.txtemailuser)
        Me.Controls.Add(Me.txtnmuser)
        Me.Controls.Add(Me.txtpwuser)
        Me.Controls.Add(Me.txtusernameuser)
        Me.Controls.Add(Me.txtalmtuser)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label1)
        Me.Name = "formregistrasi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "REGISTRASI"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txttlpuser As TextBox
    Friend WithEvents txtemailuser As TextBox
    Friend WithEvents txtnmuser As TextBox
    Friend WithEvents txtpwuser As TextBox
    Friend WithEvents txtusernameuser As TextBox
    Friend WithEvents txtalmtuser As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents btnbtlregist As Button
    Friend WithEvents btndaftar As Button
    Friend WithEvents txtusrid As TextBox
End Class
