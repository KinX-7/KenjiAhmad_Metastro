﻿Imports System.Data.SqlClient
Imports System.Collections.Generic

Public Class Dashboard
    Dim batasbuku As Integer = 7
    Dim uniqueValues As New HashSet(Of String)()
    Public Sub peminjamansaya()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT jmlPinjam FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then

                    lbljmlpinjam.Text = reader("jmlPinjam").ToString()

                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Public Sub peminjamansaya2()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT jmlPinjam FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then

                    lbljmlpinjam.Text = reader("jmlPinjam").ToString()

                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Sub updatejmlPinjam()
        Try
            ' Menghitung jumlah baris yang valid (bukan baris baru) dalam DataGridView
            Dim jmlPinjam As Integer = dgvkranjang.Rows.Cast(Of DataGridViewRow)().Where(Function(row) Not row.IsNewRow).Count()

            ' Perbarui nilai jmlPinjam dalam tabel tbl_user untuk UserID yang sesuai
            Dim queryUpdate As String = "UPDATE tbl_user SET jmlPinjam=@jmlPinjam WHERE UserID=@userID"
            Dim cmdUpdate As New SqlCommand(queryUpdate, conn)
            cmdUpdate.Parameters.AddWithValue("@jmlPinjam", jmlPinjam)
            cmdUpdate.Parameters.AddWithValue("@userID", txtusridpnjm.Text)

            ' Eksekusi perintah UPDATE
            cmdUpdate.ExecuteNonQuery()



        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

    End Sub
    Sub inserttbl2()
        For baris As Integer = 0 To dgvkranjang.Rows.Count - 2
            Call koneksi()
            Dim simpandtl As String = "Insert into tbl_mst_dtl_pinjam(PeminjamanID, UserID, BukuID, Judul, Kategori) values('" & txtkdpnjm.Text & "', '" & txtusridpnjm.Text & "','" & dgvkranjang.Rows(baris).Cells(0).Value & "', '" & dgvkranjang.Rows(baris).Cells(1).Value & "','" & dgvkranjang.Rows(baris).Cells(2).Value & "')"
            cmd = New SqlCommand(simpandtl, conn)
            cmd.ExecuteNonQuery()

        Next
        Call kondisiawalpinjam()
    End Sub
    Sub kondisiawalpinjam()
        txtbkidpnjm.Text = ""
        txtjdlpnjm.Text = ""
        txtktgrpnjm.Text = ""
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub
    Public Sub userdatamu()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then

                    txtdummyid.Text = reader("UserID").ToString()

                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Public Sub userdata()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID, Username, Password, Nama, Email, Telp, Alamat FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    txtuseriddb.Text = reader("UserID").ToString()
                    txtusrnmdb.Text = reader("Username").ToString()
                    txtpwdb.Text = reader("Password").ToString()
                    txtnmdb.Text = reader("Nama").ToString()
                    txtemldb.Text = reader("Email").ToString()
                    txttlpdb.Text = reader("Telp").ToString()
                    txtalmtdb.Text = reader("Alamat").ToString()
                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Sub autoidpinjam()
        Call koneksi()
        Dim query As New SqlCommand("select * from tbl_pinjam where PeminjamanID in(select max(PeminjamanID) from tbl_pinjam)", conn)
        Dim er = query.ExecuteReader
        er.Read()

        If Not er.HasRows Then
            txtkdpnjm.Text = "PJM" + "001"
            conn.Close()
        Else
            Dim cekid = Microsoft.VisualBasic.Right(er.GetString(0), 3) + 1
            txtkdpnjm.Text = "PJM" + Microsoft.VisualBasic.Right("000" & cekid, 3)

        End If
    End Sub
    Sub callingusrdata()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID, Username, Password, Nama, Email, Telp, Alamat FROM tbl_user WHERE Username = @Username"
        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    txtusridpnjm.Text = reader("UserID").ToString()
                    txtnmusrpnjm.Text = reader("Nama").ToString()
                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    'Sub tglpinjam()
    '    txttglpnjm.Text = Today
    'End Sub
    Sub kondisidatabuku()
        txtidbkdt.Text = ""
        txtjdldt.Text = ""
        txtktgdt.Text = ""
        txtpnlsdt.Text = ""
        txtpnrbtdt.Text = ""
        txtthntrbtdt.Text = ""
        txtrtgdt.Text = ""
        ptbbkdt.ImageLocation = ""
        Call koneksi()
        da = New SqlDataAdapter("select BukuID, Judul, Penulis, Penerbit, TahunTerbit, gambar, Rating from tbl_buku", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_buku")
        DataGridView1.DataSource = (ds.Tables("tbl_buku"))
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub
    Sub ketemubuku()
        On Error Resume Next
        txtjdldt.Text = rd(1) '=Judul
        txtktgdt.Text = rd(2) '=Kategori
        txtpnlsdt.Text = rd(3) '=Penulis
        txtpnrbtdt.Text = rd(4) '=Penerbit
        txtthntrbtdt.Text = rd(5) '=Tahunterbit 
        ptbbkdt.ImageLocation = rd(6) '=gambar
        txtrtgdt.Text = rd(7) '=Rating
        rd.Close()
    End Sub
    Sub carikodebuku()

        cmd = New SqlCommand("select * from tbl_buku where BukuID='" & txtidbkdt.Text & "'", conn)
        rd = cmd.ExecuteReader
        rd.Read()

    End Sub
    Sub peminjamanpribadi()
        Call koneksi()
        da = New SqlDataAdapter("select PeminjamanID, UserID, BukuID, Judul, Kategori from tbl_mst_dtl_pinjam where UserID like '%" & txtdummyid.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_mst_dtl_pinjam")
        dgvmu.DataSource = (ds.Tables("tbl_mst_dtl_pinjam"))
        dgvmu.DataSource = ds.Tables(0)
        dgvmu.ReadOnly = True
        dgvmu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub
    Public Sub userdatapnl()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT Nama FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then

                    Label6.Text = reader("Nama").ToString()

                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Public Sub iduserkoleksi()
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=db_ukom;User ID=sa;Password=123456789"
        Dim query As String = "SELECT UserID FROM tbl_user WHERE Username = @Username"

        Using connection As New SqlConnection(connectionString)
            Dim command As New SqlCommand(query, connection)
            command.Parameters.AddWithValue("@Username", formlogin.TextBox1.Text)

            Try
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then

                    TextBox1.Text = reader("UserID").ToString()

                Else
                    MessageBox.Show("Data tidak ditemukan")
                End If

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub Label22_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        peminjamanpribadi()
        pnlMain.Visible = True
        pnldataBuku.Visible = False
        pnltranspinjam.Visible = False
        pnlDataDiri.Visible = False
        pnlKoleksi.Visible = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DateTimePicker2.Value = DateTimePicker1.Value.AddDays(5)
        pnlMain.Visible = False
        pnldataBuku.Visible = False
        pnltranspinjam.Visible = True
        pnlDataDiri.Visible = False
        pnlKoleksi.Visible = False
    End Sub

    Private Sub pnlMain_Paint(sender As Object, e As PaintEventArgs) Handles pnlMain.Paint

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If MessageBox.Show("Yakin Ingin Keluar?", "Peringatan!", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            conn.Close()
            formlogin.TextBox1.Clear()
            formlogin.TextBox2.Clear()
            formlogin.TextBox1.Focus()
            Me.Close()
            formlogin.Show()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)

        editdatauser.ShowDialog()
    End Sub

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Visible = False
        lbljmlpinjam.Text = "0"
        txtdummyid.Visible = False
        txtusridpnjm.Visible = False
        txtnmusrpnjm.Visible = False
        Call userdatapnl()
        Call iduserkoleksi()
        'Call koleksidata()
        Call filterkoleksi()
        Call userdatamu()
        Call peminjamansaya()
        Call peminjamansaya2()
        Call userdata()
        Call autoidpinjam()
        Call callingusrdata()
        'Call tglpinjam()
        Call kondisidatabuku()
        Call peminjamanpribadi()
        dgvkranjang.ReadOnly = True
        dgvkranjang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
    End Sub

    Private Sub pnlNav_Paint(sender As Object, e As PaintEventArgs) Handles pnlNav.Paint

    End Sub

    Private Sub pnltranspinjam_Paint(sender As Object, e As PaintEventArgs) Handles pnltranspinjam.Paint

    End Sub

    Private Sub txttglpnjm_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        'Dim dataid2 As String = txtbkidpnjm.Text.Trim()

        '' Memeriksa apakah ID buku sudah ada sebelumnya dan jumlah baris tidak melebihi 5
        'If Not String.IsNullOrEmpty(dataid2) AndAlso uniqueValues.Add(dataid2) AndAlso dgvkranjang.Rows.Count < 5 Then
        '    ' Jika tidak ada baris, tambahkan baris secara manual
        '    If dgvkranjang.Rows.Count = 0 Then
        '        dgvkranjang.Rows.Add()
        '    End If

        '    dgvkranjang.Rows.Add(dataid2, txtjdlpnjm.Text.Trim(), txtktgrpnjm.Text.Trim())
        '    MsgBox("Berhasil menambahkan buku ke keranjang!", vbInformation, "Berhasil!")
        '    txtbkidpnjm.Text = ""
        '    txtjdlpnjm.Text = ""
        '    txtktgrpnjm.Text = ""
        'ElseIf dgvkranjang.Rows.Count >= 5 Then
        '    MsgBox("Jumlah buku yang Anda pinjam sudah mencapai batas.", vbExclamation, "Peringatan")
        'Else
        '    MsgBox("Tidak bisa memilih buku yang sama.", vbExclamation, "Peringatan")
        'End If

        Dim dataid2 As String = txtbkidpnjm.Text.Trim()

        ' Memeriksa apakah ID buku sudah ada sebelumnya dan jumlah baris tidak melebihi 5
        If Not String.IsNullOrEmpty(dataid2) AndAlso uniqueValues.Add(dataid2) AndAlso dgvkranjang.Rows.Count < batasbuku Then
            'Jika tidak ada baris, tambahkan baris secara manual dan hapus baris tambahan yang tidak diinginkan
            If dgvkranjang.Rows.Count = 1 AndAlso dgvkranjang.Rows(0).Cells(0).Value Is Nothing Then
                dgvkranjang.Rows.Clear()
            End If
            ' Cek nilai sel pertama pada baris tambahan
            If dgvkranjang.Rows.Count = 1 AndAlso dgvkranjang.Rows(0).Cells(0).Value IsNot Nothing Then
                MsgBox("Nilai sel pertama pada baris tambahan: " & dgvkranjang.Rows(0).Cells(0).Value.ToString())
            End If

            dgvkranjang.Rows.Add(dataid2, txtjdlpnjm.Text.Trim(), txtktgrpnjm.Text.Trim())
            MsgBox("Berhasil menambahkan buku ke keranjang!", vbInformation, "Berhasil!")
            txtbkidpnjm.Text = ""
            txtjdlpnjm.Text = ""
            txtktgrpnjm.Text = ""
        ElseIf dgvkranjang.Rows.Count >= 5 Then
            MsgBox("Jumlah buku yang Anda pinjam sudah mencapai batas.", vbExclamation, "Peringatan")
        Else
            MsgBox("Tidak bisa memilih buku yang sama.", vbExclamation, "Peringatan")
        End If

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        caribuku.ShowDialog()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs)
        'validasi.ShowDialog()
        If MessageBox.Show("Yakin Ingin Menghapus Akun Anda?", "Peringatan!", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Call koneksi()
            Dim DELETE As String = "delete tbl_user where UserID='" & txtuseriddb.Text & "'"
            cmd = New SqlCommand(DELETE, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Akun Anda Berhasil Dihapus!", vbInformation, "Pemberitahuan!")
            formlogin.TextBox1.Text = ""
            formlogin.TextBox2.Text = ""
            Me.Hide()
            formlogin.ShowDialog()
        End If
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click

        UlasanBuku.ShowDialog()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        txtidbkdt.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        Call carikodebuku()
        If rd.HasRows Then
            Call ketemubuku()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call kondisidatabuku()
        Call UlasanBuku.kondisi()
        pnlMain.Visible = False
        pnldataBuku.Visible = True
        pnltranspinjam.Visible = False
        pnlDataDiri.Visible = False
        pnlKoleksi.Visible = False
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim dataid2 As String = txtidbkdt.Text.Trim()

        ' Memeriksa apakah ID buku sudah ada sebelumnya dan jumlah baris tidak melebihi 5
        If Not String.IsNullOrEmpty(dataid2) AndAlso uniqueValues.Add(dataid2) AndAlso dgvkranjang.Rows.Count <= batasbuku Then
            'Dim buttondelete As New DataGridViewButtonColumn
            'buttondelete.UseColumnTextForButtonValue = True
            'buttondelete.HeaderText = "Hapus"
            'buttondelete.Width = 100
            'buttondelete.Text = "Hapus"
            'buttondelete.DefaultCellStyle.BackColor = Color.Red
            'buttondelete.FlatStyle = FlatStyle.Flat
            ''dgvkranjang.Columns.Insert(3, buttondelete)
            ' Hapus baris pertama jika itu adalah baris tambahan
            If dgvkranjang.Rows.Count > 1 AndAlso dgvkranjang.Rows(0).Cells(0).Value Is Nothing Then
                dgvkranjang.Rows.RemoveAt(0)
            End If

            dgvkranjang.Rows.Add(dataid2, txtjdldt.Text.Trim(), txtktgdt.Text.Trim())
            MsgBox("Berhasil menambahkan buku ke keranjang!", vbInformation, "Berhasil!")

        ElseIf dgvkranjang.Rows.Count >= 5 Then
            MsgBox("Jumlah buku yang Anda pinjam sudah mencapai batas.", vbExclamation, "Peringatan")
        Else
            MsgBox("Tidak bisa memilih buku yang sama.", vbExclamation, "Peringatan")
        End If
    End Sub

    Private Sub dgvkranjang_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvkranjang.CellContentClick

        'Dim dataid2 As String = txtbkidpnjm.Text.Trim()

        ' Memeriksa apakah ID buku sudah ada sebelumnya dan jumlah baris tidak melebihi 5
        'If Not String.IsNullOrEmpty(dataid2) AndAlso uniqueValues.Add(dataid2) AndAlso dgvkranjang.Rows.Count < 5 Then
        '    ' Hapus baris tambahan jika ada
        '    For Each row As DataGridViewRow In dgvkranjang.Rows
        '        If row.Cells(0).Value Is Nothing Then
        '            dgvkranjang.Rows.Remove(row)
        '            Exit For ' Hanya perlu menghapus satu baris
        '        End If
        '    Next

        '    dgvkranjang.Rows.Add(dataid2, txtjdlpnjm.Text.Trim(), txtktgrpnjm.Text.Trim())
        '    MsgBox("Berhasil menambahkan buku ke keranjang!", vbInformation, "Berhasil!")
        '    txtbkidpnjm.Text = ""
        '    txtjdlpnjm.Text = ""
        '    txtktgrpnjm.Text = ""
        'ElseIf dgvkranjang.Rows.Count >= 5 Then
        '    MsgBox("Jumlah buku yang Anda pinjam sudah mencapai batas.", vbExclamation, "Peringatan")
        'Else
        '    MsgBox("Tidak bisa memilih buku yang sama.", vbExclamation, "Peringatan")
        'End If
        Dim dataid2 As String = txtbkidpnjm.Text.Trim()

        ' Memeriksa apakah ID buku sudah ada sebelumnya dan jumlah baris tidak melebihi 5
        If Not String.IsNullOrEmpty(dataid2) AndAlso uniqueValues.Add(dataid2) AndAlso dgvkranjang.Rows.Count < batasbuku Then
            ' Hapus baris pertama jika itu adalah baris tambahan
            If dgvkranjang.Rows.Count > 1 AndAlso dgvkranjang.Rows(0).Cells(0).Value Is Nothing Then
                dgvkranjang.Rows.RemoveAt(0)
            End If
            Dim mycell As Integer
            mycell = dgvkranjang.CurrentCell.RowIndex
            If MessageBox.Show("Hapus item?", "Pemberitahuan", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                dgvkranjang.Rows.RemoveAt(mycell)
                dgvkranjang.Refresh()
            End If
            'dgvkranjang.Rows.Add(dataid2, txtjdlpnjm.Text.Trim(), txtktgrpnjm.Text.Trim())

            '    txtbkidpnjm.Text = ""
            '    txtjdlpnjm.Text = ""
            '    txtktgrpnjm.Text = ""
            'ElseIf dgvkranjang.Rows.Count >= 5 Then
            '    MsgBox("Jumlah buku yang Anda pinjam sudah mencapai batas.", vbExclamation, "Peringatan")
            'Else
            '    MsgBox("Tidak bisa memilih buku yang sama.", vbExclamation, "Peringatan")
            'End If
        End If
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        txtbkidpnjm.Text = ""
        txtjdlpnjm.Text = ""
        txtktgrpnjm.Text = ""
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        DateTimePicker2.Value = DateTimePicker1.Value.AddDays(5)
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        'Dim rowcount As Integer = dgvkranjang.RowCount = -0
        Dim rowcount As Integer = dgvkranjang.Rows.Cast(Of DataGridViewRow)().Where(Function(row) Not row.IsNewRow).Count()
        Dim statuspjm As String = "Dipinjam"
        'If txtbkidpnjm.Text = "" Or txtjdlpnjm.Text = "" Or txtktgrpnjm.Text = "" Then
        Call koneksi()
        Dim query1 As String = "insert into tbl_pinjam (PeminjamanID, UserID, Nama, TanggalPeminjaman, TanggalTenggat, Jumlah, Status) values('" & txtkdpnjm.Text & "','" & txtusridpnjm.Text & "','" & txtnmusrpnjm.Text & "','" & DateTimePicker1.Value & "','" & DateTimePicker2.Value & "','" & rowcount & "','" & statuspjm & "')"

        cmd = New SqlCommand(query1, conn)
        cmd.ExecuteNonQuery()
        Call inserttbl2()
        Call updatejmlPinjam()
        Call peminjamansaya()


        MsgBox("Peminjaman Berhasil!", vbInformation, "SUKSES!")
        Call peminjamansaya2()
        Call autoidpinjam()
        dgvkranjang.Rows.Clear()
        'pnltranspinjam.Visible = False
        'pnlMain.Visible = True

        conn.Close()

    End Sub
    'Sub koleksidata()
    '    Call koneksi()
    '    da = New SqlDataAdapter("select BukuID, Judul, Kategori, Ulasan, Rating from tbl_koleksi", conn)
    '    ds = New DataSet
    '    da.Fill(ds, "tbl_koleksi")
    '    dgvkoleksi.DataSource = (ds.Tables("tbl_koleksi"))
    '    dgvkoleksi.DataSource = ds.Tables(0)
    '    dgvkoleksi.ReadOnly = True

    'End Sub
    Public Sub filterkoleksi()
        Call koneksi()
        da = New SqlDataAdapter("Select BukuID, Judul, Kategori, Ulasan, Rating from tbl_koleksi where UserID like '%" & TextBox1.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "tbl_koleksi")
        dgvkoleksi.DataSource = (ds.Tables("tbl_koleksi"))
        dgvkoleksi.DataSource = ds.Tables(0)
        dgvkoleksi.ReadOnly = True
        dgvkoleksi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
        'Dim buttoncolumn As New DataGridViewButtonColumn
        'buttoncolumn.UseColumnTextForButtonValue = True
        'buttoncolumn.HeaderText = "BeriUlasan"
        'buttoncolumn.Width = 100
        'buttoncolumn.Text = "Beri Ulasan"
        'buttoncolumn.DefaultCellStyle.BackColor = Color.Orange
        'buttoncolumn.FlatStyle = FlatStyle.Flat
        'dgvkoleksi.Columns.Insert(5, buttoncolumn)
    End Sub
    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        editdatauser.ShowDialog()
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        pnlMain.Visible = False
        pnldataBuku.Visible = False
        pnltranspinjam.Visible = False
        pnlDataDiri.Visible = True
        pnlKoleksi.Visible = False
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        pnlMain.Visible = False
        pnldataBuku.Visible = False
        pnltranspinjam.Visible = False
        pnlDataDiri.Visible = False
        pnlKoleksi.Visible = True
    End Sub

    Private Sub dgvmu_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvmu.CellContentClick

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        pnlMain.Visible = True
        pnldataBuku.Visible = False
        pnltranspinjam.Visible = False
        pnlDataDiri.Visible = False
        pnlKoleksi.Visible = False
    End Sub

    Private Sub dgvkoleksi_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvkoleksi.CellContentClick
        BeriUlasan.ShowDialog()
    End Sub
End Class